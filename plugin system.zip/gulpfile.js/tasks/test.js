/* global console */
/* global module */

module.exports = function($) {
  return function(done) {
    // TBD
  };
};
