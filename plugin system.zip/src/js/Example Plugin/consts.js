var __modulename = 'example_plugin';
var __pluginname = 'ExamplePlugin';
var __version = [0, 0, 1];
var __description = 'This is just an example plugin.';
var __author = 'Joel Dies <phreaknation@gmail.com>';

var __schemas = {};
