plugin.prototype.test = function test(str)  {
  return 'This is an example of how to return a string. ' + str;
};
