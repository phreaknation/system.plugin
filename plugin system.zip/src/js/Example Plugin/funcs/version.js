plugin.prototype.version = function version()  {
  return __version.join('.');
};
